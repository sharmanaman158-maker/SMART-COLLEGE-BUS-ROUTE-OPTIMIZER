const API = "http://localhost:8080";

// LOGIN
function login(){
    fetch(API + "/api/login", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            username: document.getElementById("user").value,
            password: document.getElementById("pass").value
        })
    })
    .then(res => res.json())
    .then(data => {

        if(!data || !data.role){
            document.getElementById("error").innerText = "Invalid login!";
            return;
        }

        localStorage.setItem("role", data.role);

        if(data.role === "admin")
            window.location = "admin.html";
        else
            window.location = "student.html";
    })
    .catch(() => {
        document.getElementById("error").innerText = "Server error!";
    });
}
document.getElementById("error").innerText = "";

// LOGOUT
function logout(){
    localStorage.clear();
    window.location = "index.html";
}

// MAP INIT
let map;
let route = [];
let marker;
let index = 0;

function initMap() {
    if (map) return;

    map = L.map('map').setView([30.3165, 78.0322], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap'
    }).addTo(map);
}

// LOAD ROUTE
function loadRoute(){
    fetch("http://localhost:8080/route/dijkstra")
    .then(res => res.json())
    .then(data => {

        route = data.map(p => [p.lat, p.lng]);

        L.polyline(route, {color:'blue'}).addTo(map);

        route.forEach(p => L.marker(p).addTo(map));
    })
    .catch(err => console.log(err));
}

// BUS ANIMATION
function startBus(){

    if(route.length === 0){
        alert("Load route first!");
        return;
    }

    marker = L.marker(route[0]).addTo(map);

    setInterval(() => {
        index = (index + 1) % route.length;
        marker.setLatLng(route[index]);
    }, 2000);
}