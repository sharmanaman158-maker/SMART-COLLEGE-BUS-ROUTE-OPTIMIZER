package com.bus.service;

import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RouteService {

    // Graph representation
    private Map<String, List<Node>> graph = new HashMap<>();

    public RouteService() {
        // Sample Dehradun graph
        graph.put("College", List.of(
                new Node("ISBT", 5),
                new Node("ClockTower", 8)
        ));

        graph.put("ISBT", List.of(
                new Node("PremNagar", 7)
        ));

        graph.put("ClockTower", List.of(
                new Node("PremNagar", 3)
        ));

        graph.put("PremNagar", new ArrayList<>());
    }

    // =========================
    // DIJKSTRA SHORTEST PATH
    // =========================
    public Map<String, Integer> getShortestPaths(String source) {

        Map<String, Integer> dist = new HashMap<>();
        PriorityQueue<Node> pq = new PriorityQueue<>(Comparator.comparingInt(n -> n.cost));

        // Initialize distances
        for (String v : graph.keySet()) {
            dist.put(v, Integer.MAX_VALUE);
        }

        dist.put(source, 0);
        pq.add(new Node(source, 0));

        while (!pq.isEmpty()) {
            Node current = pq.poll();

            for (Node neighbor : graph.getOrDefault(current.name, new ArrayList<>())) {

                int newDist = dist.get(current.name) + neighbor.cost;

                if (newDist < dist.get(neighbor.name)) {
                    dist.put(neighbor.name, newDist);
                    pq.add(new Node(neighbor.name, newDist));
                }
            }
        }

        return dist;
    }

    // =========================
    // MST (PRIM'S ALGORITHM)
    // =========================
    public int getMSTCost() {

        Set<String> visited = new HashSet<>();
        PriorityQueue<Node> pq = new PriorityQueue<>(Comparator.comparingInt(n -> n.cost));

        String start = "College";
        visited.add(start);

        pq.addAll(graph.get(start));

        int totalCost = 0;

        while (!pq.isEmpty()) {
            Node current = pq.poll();

            if (visited.contains(current.name)) continue;

            visited.add(current.name);
            totalCost += current.cost;

            for (Node neighbor : graph.getOrDefault(current.name, new ArrayList<>())) {
                if (!visited.contains(neighbor.name)) {
                    pq.add(neighbor);
                }
            }
        }

        return totalCost;
    }

    // =========================
    // NODE CLASS
    // =========================
    static class Node {
        String name;
        int cost;

        Node(String name, int cost) {
            this.name = name;
            this.cost = cost;
        }
    }
}