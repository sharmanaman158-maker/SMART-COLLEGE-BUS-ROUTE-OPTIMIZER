package com.bus.service;

import com.bus.model.User;
import com.bus.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    UserRepository repo;

    public User login(String u, String p) {
        return repo.findByUsernameAndPassword(u, p);
    }
}