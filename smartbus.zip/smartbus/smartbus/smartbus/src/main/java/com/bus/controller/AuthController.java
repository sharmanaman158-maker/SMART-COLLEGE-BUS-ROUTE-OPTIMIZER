package com.bus.controller;

import com.bus.model.User;
import com.bus.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class AuthController {

    @Autowired
    AuthService service;

    @PostMapping("/login")
    public User login(@RequestBody User user) {
        return service.login(user.username, user.password);
    }
}