public class Dijkstra {
    static class Node {
        String name; int cost;
        Node(String n,int c){name=n;cost=c;}
    }
}
