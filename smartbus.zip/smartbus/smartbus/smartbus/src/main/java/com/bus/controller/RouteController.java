package com.bus.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/route")
@CrossOrigin
public class RouteController {

    @GetMapping("/dijkstra")
    public List<Map<String, Object>> dijkstra() {

        List<Map<String, Object>> route = new ArrayList<>();

        route.add(point("College", 30.3165, 78.0322));
        route.add(point("ISBT", 30.2880, 78.0160));
        route.add(point("ClockTower", 30.3256, 78.0437));
        route.add(point("PremNagar", 30.3345, 77.9981));

        return route;
    }

    @GetMapping("/mst")
    public Map<String, Integer> mst() {
        Map<String, Integer> map = new HashMap<>();
        map.put("TotalDistance", 20);
        return map;
    }

    private Map<String, Object> point(String name, double lat, double lng) {
        Map<String, Object> p = new HashMap<>();
        p.put("name", name);
        p.put("lat", lat);
        p.put("lng", lng);
        return p;
    }
}