const express = require("express");
const path = require("path");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

// ---------------- LOGIN ----------------
app.post("/api/login", (req, res) => {
    const { username, password } = req.body;

    if (username === "admin" && password === "admin123") {
        return res.json({ success: true, role: "admin" });
    }

    if (username === "student" && password === "123") {
        return res.json({ success: true, role: "student" });
    }

    res.json({ success: false });
});

// ---------------- BUS STORAGE ----------------
let buses = [
    { id: 1, route: "Dehradun - Prem Nagar", seats: 40, lat: 30.3165, lng: 78.0322 }
];

// ---------------- PICKUP POINTS ----------------
let pickupPoints = [
    { id: 1, name: "Prem Nagar", lat: 30.3165, lng: 78.0322 },
    { id: 2, name: "ISBT", lat: 30.3250, lng: 78.0410 }
];

// ---------------- APIs ----------------

// Get buses
app.get("/api/buses", (req, res) => {
    res.json(buses);
});

// Add bus
app.post("/api/add-bus", (req, res) => {
    const { route, seats } = req.body;

    buses.push({
        id: Date.now(),
        route,
        seats,
        lat: 30.3165,
        lng: 78.0322
    });

    res.json({ success: true });
});

// Get pickup points
app.get("/api/pickups", (req, res) => {
    res.json(pickupPoints);
});

// Add pickup point (ADMIN)
app.post("/api/add-pickup", (req, res) => {
    const { name, lat, lng } = req.body;

    pickupPoints.push({
        id: Date.now(),
        name,
        lat,
        lng
    });

    res.json({ success: true });
});

// Simulate bus movement
setInterval(() => {
    buses.forEach(bus => {
        bus.lat += (Math.random() - 0.5) * 0.001;
        bus.lng += (Math.random() - 0.5) * 0.001;
    });
}, 4000);

app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
});